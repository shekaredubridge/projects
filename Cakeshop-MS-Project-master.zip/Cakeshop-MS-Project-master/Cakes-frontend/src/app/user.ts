export class User {
   name!:String;
    email!:String;
    password!:String;
    registrationCode!:String;
}