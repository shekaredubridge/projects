import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contac-us',
  templateUrl: './contac-us.component.html',
  styleUrls: ['./contac-us.component.css']
})
export class ContacUsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
