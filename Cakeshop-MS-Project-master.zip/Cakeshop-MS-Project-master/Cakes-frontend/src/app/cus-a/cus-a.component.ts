import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cus-a',
  templateUrl: './cus-a.component.html',
  styleUrls: ['./cus-a.component.css']
})
export class CusAComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
