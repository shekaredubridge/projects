export class Admin {
    name!:String;
    email!:String;
    keyword!:String;
    password!:String;
}
    
